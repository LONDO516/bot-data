/* <--! CREATED BY LONDO !-->

Telegram Developer @londohost
Join Channel Info Update @Londohost

*/
module.exports = {
  BOT_TOKEN: "8231824587:AAGq-VaL6kCOcnxAB2735FuyeBQmH5qGYkY",
  OWNER_ID: ["8485662776"],
};